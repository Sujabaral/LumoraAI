# train_chatbot.py
# --------------------------------------------------------------------------------------------
# PRODUCTION-READY INTENT TRAINER (TF-IDF + history features, intents.json + DB supervision)
#
# Trains on BOTH:
#   A) intents.json patterns  (intent["patterns"] -> intent["tag"])
#   B) DB labeled messages     (ChatMessage.intent_tag)
#
# Improvements applied:
#   ✅ CORE collapsing ON (fewer, learnable intent buckets)
#   ✅ Skip system/routing labels entirely (mistral/rule_* etc.)
#   ✅ Increase DB influence (real user language)
#   ✅ Reduce intents oversampling bias (cap + lower min)
#
# Saves:
#   ChatbotWebsite/static/data/chatbot-model.keras   (recommended)
#   ChatbotWebsite/static/data/chatbot-model.h5      (optional export)
#   ChatbotWebsite/static/data/chatbot_meta.pkl
# --------------------------------------------------------------------------------------------

from __future__ import annotations

import os
import json
import pickle
import random
import re
from typing import List, Dict, Any, Optional, Tuple
from collections import Counter, defaultdict

import numpy as np

import nltk
from nltk.stem import WordNetLemmatizer

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, Input
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

# M1/M2 optimizer slowdown workaround (safe on Intel too)
try:
    from tensorflow.keras.optimizers.legacy import Adam as LegacyAdam
    AdamOpt = LegacyAdam
except Exception:
    from tensorflow.keras.optimizers import Adam as AdamOpt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.utils.class_weight import compute_class_weight


# ------------------ Config ------------------
SEED = 42

INTENTS_PATH = "ChatbotWebsite/static/data/intents.json"
OUT_DIR = "ChatbotWebsite/static/data"
MODEL_PATH_KERAS = os.path.join(OUT_DIR, "chatbot-model.keras")   # ✅ recommended
MODEL_PATH_H5 = os.path.join(OUT_DIR, "chatbot-model.h5")         # optional
META_PATH = os.path.join(OUT_DIR, "chatbot_meta.pkl")

N_HISTORY = 10

# weighting (DB is more realistic, but usually smaller)
INTENTS_REPEAT = 1
DB_REPEAT = 10  # ✅ more DB weight (real chat > patterns)

# ✅ CORE collapsing: fewer useful buckets
USE_CORE_INTENTS = True  # ✅ turned ON for better real-chat behavior

# ✅ BALANCING for intents.json patterns
INTENTS_CAP_PER_LABEL = 150     # ✅ lower than 200 to reduce overfitting
INTENTS_MIN_PER_LABEL = 40      # ✅ lower than 80 to reduce duplication bias

# TF-IDF
MAX_FEATURES = 8000
NGRAM_RANGE = (1, 2)
MIN_DF = 2

# Training
EPOCHS = 200
BATCH_SIZE = 32
LEARNING_RATE = 1e-3

# ✅ Remove system/routing labels from training
SKIP_LABELS = {
    "mistral",
    "mistral_direct",
    "brain+mistral",
    "rule_greeting",
    "rule_short",
    "rule_uncertainty",
}


# ------------------ Determinism ------------------
def seed_everything(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)


seed_everything(SEED)


# ------------------ NLTK setup (download only if missing) ------------------
def _ensure_nltk():
    try:
        nltk.data.find("tokenizers/punkt")
    except LookupError:
        nltk.download("punkt")

    try:
        nltk.data.find("corpora/wordnet")
    except LookupError:
        nltk.download("wordnet")


_ensure_nltk()
lemmatizer = WordNetLemmatizer()


# ------------------ Tag normalization ------------------
def norm_tag(tag: str) -> str:
    return (tag or "").strip().lower()


# ------------------ Core collapsing (expanded to cover DB-only labels) ------------------
# Goal: collapse many fine-grained labels into fewer "learnable & useful" buckets.
CORE_MAP: Dict[str, str] = {
    # basic
    "greeting": "greeting",
    "goodbye": "goodbye",
    "thanks": "thanks",
    "bot_identity": "general",
    "affirmation_short": "general",
    "repeat_clarify": "general",
    "disagreement": "general",
    "fallback": "general",
    "general": "general",
    "fun": "fun",
    "jokes": "fun",

    # anxiety family
    "anxiety": "anxiety",
    "anxiety_definition": "anxiety",
    "anxiety_feeling": "anxiety",
    "anxiety_help": "anxiety",
    "panic_attack": "anxiety",

    # stress/burnout family
    "stress": "stress",
    "stress_burnout_definition": "stress",
    "stress_burnout_feeling": "stress",
    "stress_burnout_help": "stress",
    "procrastination": "stress",
    "anger": "anger",

    # depression/sadness family
    "depression_definition": "depression",
    "depression_feeling": "depression",
    "depression_help": "depression",
    "sadness": "depression",
    "self_esteem": "depression",

    # loneliness / relationship
    "loneliness_definition": "loneliness",
    "loneliness_feeling": "loneliness",
    "loneliness_help": "loneliness",
    "relationship_issues": "relationship",

    # crisis / suicide risk
    "immediate_danger": "crisis",
    "crisis_suicidal": "crisis",
    "crisis": "crisis",
    "suicidal": "crisis",

    # coping / skills
    "coping_skills": "coping",
    "grounding_54321": "coping",
    "breathing_exercises": "coping",
    "mindfulness_grounding": "coping",
    "wellbeing_basics": "coping",

    # sleep / journaling
    "sleep_issues": "sleep",
    "journaling": "journaling",

    # professional / services
    "professional_help": "professional_help",
    "services_nepal": "professional_help",
    "book_appointment": "professional_help",
    "find_doctor": "professional_help",
    "doctor_vs_therapist": "professional_help",
    "medication_general": "professional_help",

    # extra DB-only topics (map to useful buckets)
    "addiction_definition": "addiction",
    "addiction_help": "addiction",
    "addiction_signs": "addiction",
    "bipolar_definition": "bipolar",
    "ocd_definition": "ocd",
    "ptsd_definition": "ptsd",
    "schizophrenia_definition": "schizophrenia",
    "borderline_personality_disorder": "personality",
    "psychosis_general": "psychosis",
    "eating_disorders": "eating_disorders",
    "cultural_mental_health": "culture",
    "racism_mental_health": "culture",
    "motivation_goals": "motivation",
}

# (Optional) heuristic mapping if DB introduces new tags later
def _heuristic_core(t: str) -> str:
    # If new tags appear, attempt a safe collapse.
    if "addiction" in t:
        return "addiction"
    if "bipolar" in t:
        return "bipolar"
    if "ocd" in t:
        return "ocd"
    if "ptsd" in t:
        return "ptsd"
    if "schizophrenia" in t:
        return "schizophrenia"
    if "psychosis" in t:
        return "psychosis"
    if "eating" in t:
        return "eating_disorders"
    if "culture" in t or "racism" in t:
        return "culture"
    if "motivation" in t or "goal" in t:
        return "motivation"
    if "anger" in t:
        return "anger"
    # Default collapse
    return "general"


def to_label(tag: str) -> str:
    t = norm_tag(tag)
    if not USE_CORE_INTENTS:
        return t
    if t in CORE_MAP:
        return CORE_MAP[t]
    return _heuristic_core(t)


# ------------------ Text cleaning (MUST match Flask inference) ------------------
_CONTRACTIONS = [
    (r"can't", "can not"),
    (r"won't", "will not"),
    (r"n't", " not"),
    (r"'re", " are"),
    (r"'s", " is"),
    (r"'m", " am"),
    (r"'ll", " will"),
    (r"'ve", " have"),
]

_NON_ALNUM = re.compile(r"[^a-z0-9\s]")
_MULTI_SPACE = re.compile(r"\s+")


def clean_text(text: str) -> str:
    text = (text or "").lower().strip()
    for pat, rep in _CONTRACTIONS:
        text = re.sub(pat, rep, text)

    text = _NON_ALNUM.sub(" ", text)
    text = _MULTI_SPACE.sub(" ", text).strip()
    if not text:
        return ""

    tokens = nltk.word_tokenize(text)
    tokens = [lemmatizer.lemmatize(t) for t in tokens]
    return " ".join(tokens).strip()


# ------------------ History features (MUST match Flask inference) ------------------
HISTORY_FEATURE_NAMES = [
    "hist_count",
    "avg_tokens",
    "max_tokens",
    "min_tokens",
    "std_tokens",
    "last_tokens",
]
HISTORY_K = len(HISTORY_FEATURE_NAMES)


def history_features(history_texts: List[str]) -> np.ndarray:
    feats = np.zeros(HISTORY_K, dtype=np.float32)
    feats[0] = float(len(history_texts))

    if history_texts:
        lengths = np.array([len(h.split()) for h in history_texts], dtype=np.float32)
        feats[1] = float(np.mean(lengths))
        feats[2] = float(np.max(lengths))
        feats[3] = float(np.min(lengths))
        feats[4] = float(np.std(lengths))
        feats[5] = float(len(history_texts[-1].split()))

    return feats


# ------------------ Load intents.json + build responses_map ------------------
if not os.path.exists(INTENTS_PATH):
    raise FileNotFoundError(f"Missing intents.json at: {INTENTS_PATH}")

with open(INTENTS_PATH, "r", encoding="utf-8") as f:
    intents = json.load(f)

intents_list = intents.get("intents", []) or []
print("\n📦 intents.json loaded")
print("   Raw intents objects:", len(intents_list))
print("   USE_CORE_INTENTS:", USE_CORE_INTENTS)
print("   INTENTS_CAP_PER_LABEL:", INTENTS_CAP_PER_LABEL)
print("   INTENTS_MIN_PER_LABEL:", INTENTS_MIN_PER_LABEL)

responses_map: Dict[str, List[str]] = defaultdict(list)
patterns_by_label: Dict[str, List[str]] = defaultdict(list)

raw_pattern_count = 0
for it in intents_list:
    raw_tag = it.get("tag")
    if not raw_tag:
        continue

    # map to core label
    label = to_label(raw_tag)

    # skip system/routing labels
    if norm_tag(raw_tag) in SKIP_LABELS or label in SKIP_LABELS:
        continue

    # responses merge (core-safe)
    for r in (it.get("responses") or []):
        rr = (r or "").strip()
        if rr:
            responses_map[label].append(rr)

    # patterns
    for p in (it.get("patterns") or []):
        pp = (p or "").strip()
        if not pp:
            continue
        t = clean_text(pp)
        if not t:
            continue
        patterns_by_label[label].append(t)
        raw_pattern_count += 1

# de-dupe responses per label while preserving order
for k in list(responses_map.keys()):
    seen = set()
    uniq = []
    for r in responses_map[k]:
        if r not in seen:
            seen.add(r)
            uniq.append(r)
    responses_map[k] = uniq

print("   Labels(after mapping):", len(patterns_by_label))
print("   Patterns(raw cleaned):", raw_pattern_count)


# ------------------ Balance intents patterns ------------------
def balance_patterns(
    pats_by_label: Dict[str, List[str]],
    cap_per_label: Optional[int],
    min_per_label: Optional[int],
    seed: int
) -> Dict[str, List[str]]:
    rng = random.Random(seed)
    out: Dict[str, List[str]] = {}

    for label, pats in pats_by_label.items():
        pats = list(pats)
        rng.shuffle(pats)

        # cap big classes
        if cap_per_label is not None and len(pats) > cap_per_label:
            pats = pats[:cap_per_label]

        # oversample small classes (less aggressively now)
        if min_per_label is not None and 0 < len(pats) < min_per_label:
            need = min_per_label - len(pats)
            pats = pats + [rng.choice(pats) for _ in range(need)]

        out[label] = pats

    return out


patterns_by_label_bal = balance_patterns(
    patterns_by_label,
    cap_per_label=INTENTS_CAP_PER_LABEL,
    min_per_label=INTENTS_MIN_PER_LABEL,
    seed=SEED
)

balanced_count = sum(len(v) for v in patterns_by_label_bal.values())
print(f"   Patterns(after balance): {balanced_count}")


# ------------------ Filtering helpers (DB only) ------------------
def should_skip_message(raw: str) -> bool:
    if not raw:
        return True
    low = raw.strip().lower()

    # obvious template/system junk
    if low.startswith("(guidance)") or low.startswith("error:") or low.startswith("sorry,"):
        return True
    if "couldn't process that message" in low:
        return True
    if "gemini couldn’t process" in low or "gemini couldn't process" in low:
        return True

    botish_phrases = [
        "it sounds like you're going through",
        "remember that your worth is not defined",
        "please try again",
    ]
    return any(p in low for p in botish_phrases)


# ------------------ SAFE split helper ------------------
def safe_train_val_split(
    X: np.ndarray,
    y_onehot: np.ndarray,
    y_int: np.ndarray,
    *,
    test_size: float,
    random_state: int
):
    y_int = np.asarray(y_int)
    idx = np.arange(len(y_int))

    counts = Counter(y_int)
    rare_labels = {lab for lab, c in counts.items() if c < 2}

    rare_mask = np.isin(y_int, list(rare_labels)) if rare_labels else np.zeros_like(y_int, dtype=bool)
    rare_idx = idx[rare_mask]
    common_idx = idx[~rare_mask]

    if len(common_idx) < 2:
        X_train, X_val, y_train, y_val, y_train_int, y_val_int = train_test_split(
            X, y_onehot, y_int,
            test_size=test_size,
            random_state=random_state,
            stratify=None
        )
        return X_train, X_val, y_train, y_val, y_train_int, y_val_int

    X_c = X[common_idx]
    y_c = y_onehot[common_idx]
    y_int_c = y_int[common_idx]

    X_train_c, X_val, y_train_c, y_val, y_train_int_c, y_val_int = train_test_split(
        X_c, y_c, y_int_c,
        test_size=test_size,
        random_state=random_state,
        stratify=y_int_c
    )

    if len(rare_idx) > 0:
        X_train = np.concatenate([X_train_c, X[rare_idx]], axis=0)
        y_train = np.concatenate([y_train_c, y_onehot[rare_idx]], axis=0)
        y_train_int = np.concatenate([y_train_int_c, y_int[rare_idx]], axis=0)
    else:
        X_train, y_train, y_train_int = X_train_c, y_train_c, y_train_int_c

    rng = np.random.RandomState(random_state)
    perm = rng.permutation(len(X_train))
    X_train = X_train[perm]
    y_train = y_train[perm]
    y_train_int = y_train_int[perm]

    return X_train, X_val, y_train, y_val, y_train_int, y_val_int


# ------------------ Collect training samples (intents + DB) ------------------
print("\n🔎 Loading DB labeled chat samples (ChatMessage.intent_tag) + intents.json patterns...")

# ✅ IMPORTANT: Use minimal training app to avoid importing routes
from train_app_min import create_train_app
from ChatbotWebsite.models import ChatMessage

app = create_train_app()

samples: List[Dict[str, Any]] = []

# A) intents.json balanced patterns
added_from_intents = 0
for label, pats in patterns_by_label_bal.items():
    if label in SKIP_LABELS:
        continue
    for t in pats:
        for _ in range(INTENTS_REPEAT):
            samples.append({"text": t, "history": [], "label": label})
            added_from_intents += 1

print(f"➕ Added {added_from_intents} samples from intents.json patterns (balanced).")

# B) DB labeled messages (with history)
added_from_db = 0
skipped_db = 0

with app.app_context():
    msgs = (
        ChatMessage.query
        .filter(ChatMessage.session_id.isnot(None))
        .order_by(ChatMessage.session_id.asc(), ChatMessage.timestamp.asc())
        .all()
    )

    by_session: Dict[int, List[ChatMessage]] = {}
    for m in msgs:
        sid = getattr(m, "session_id", None)
        if sid is None:
            continue
        by_session.setdefault(sid, []).append(m)

    for sid, session_msgs in by_session.items():
        for i, m in enumerate(session_msgs):
            if getattr(m, "role", None) != "user":
                continue

            label_raw = getattr(m, "intent_tag", None)
            if not label_raw:
                continue

            # normalize + collapse
            raw_norm = norm_tag(label_raw)
            label = to_label(label_raw)

            # skip system/routing labels
            if raw_norm in SKIP_LABELS or label in SKIP_LABELS:
                continue

            raw_msg = (getattr(m, "message", "") or "").strip()
            if should_skip_message(raw_msg):
                skipped_db += 1
                continue

            curr_text = clean_text(raw_msg)
            if not curr_text:
                skipped_db += 1
                continue

            hist_slice = session_msgs[max(0, i - N_HISTORY): i]
            hist_texts: List[str] = []
            for h in hist_slice:
                if getattr(h, "role", None) != "user":
                    continue
                raw_h = (getattr(h, "message", "") or "").strip()
                if should_skip_message(raw_h):
                    continue
                ht = clean_text(raw_h)
                if ht:
                    hist_texts.append(ht)

            for _ in range(DB_REPEAT):
                samples.append({"text": curr_text, "history": hist_texts, "label": label})
                added_from_db += 1

print(f"➕ Added {added_from_db} samples from DB labeled messages. (skipped {skipped_db})")

if len(samples) < 80:
    raise ValueError(f"Too few samples. Got {len(samples)} total.")


# ------------------ Inspect distribution ------------------
texts = [s["text"] for s in samples]
labels = [s["label"] for s in samples]

unique_labels = sorted(set(labels))
print(f"\n✅ Total training samples: {len(samples)}")
print(f"✅ Unique labels (total): {len(unique_labels)}")
print("   Labels:", unique_labels)

label_counts = Counter(labels)
print("\n📊 Label counts (final):")
for k in unique_labels:
    print(f" - {k:24s}: {label_counts[k]}")


# ------------------ Encode labels ------------------
label_enc = LabelEncoder()
y = label_enc.fit_transform(labels)
num_classes = len(label_enc.classes_)
y_onehot = tf.keras.utils.to_categorical(y, num_classes=num_classes)

# class weights
classes = np.arange(num_classes)
class_weights = compute_class_weight(class_weight="balanced", classes=classes, y=y)
class_weight_dict = {i: float(w) for i, w in enumerate(class_weights)}

print("\n⚖️ Class Weights:")
for i, name in enumerate(label_enc.classes_):
    print(f" - {name:24s}: {class_weight_dict[i]:.3f}")


# ------------------ TF-IDF + history features ------------------
vectorizer = TfidfVectorizer(
    ngram_range=NGRAM_RANGE,
    min_df=MIN_DF,
    max_features=MAX_FEATURES,
    sublinear_tf=True
)

X_tfidf = vectorizer.fit_transform(texts).astype("float32").toarray()
X_hist = np.stack([history_features(s["history"]) for s in samples]).astype("float32")
X = np.concatenate([X_tfidf, X_hist], axis=1).astype("float32")

print("\n📐 Feature dimensions:")
print("   TF-IDF dim:", X_tfidf.shape[1])
print("   Hist dim  :", X_hist.shape[1])
print("   Total dim :", X.shape[1])


# ------------------ Train/Val split (SAFE) ------------------
print("\n✂️ Splitting train/val (singleton labels -> train only)...")
counts_int = np.bincount(y, minlength=num_classes)
rare_names = [label_enc.classes_[i] for i in range(num_classes) if counts_int[i] < 2]
if rare_names:
    print("⚠️ Rare labels forced into TRAIN only:", rare_names)

X_train, X_val, y_train, y_val, y_train_int, y_val_int = safe_train_val_split(
    X, y_onehot, y,
    test_size=0.2,
    random_state=SEED
)
print("   Train size:", X_train.shape[0], " Val size:", X_val.shape[0])


# ------------------ Build model ------------------
model = Sequential([
    Input(shape=(X_train.shape[1],)),
    Dense(256, activation="relu"),
    Dropout(0.35),
    Dense(128, activation="relu"),
    Dropout(0.35),
    Dense(num_classes, activation="softmax"),
])

model.compile(
    optimizer=AdamOpt(learning_rate=LEARNING_RATE),
    loss="categorical_crossentropy",
    metrics=["accuracy"]
)

early = EarlyStopping(monitor="val_loss", patience=12, restore_best_weights=True)
reduce_lr = ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=4, min_lr=1e-5, verbose=1)


# ------------------ Train ------------------
print("\n🚀 Training...")
model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    callbacks=[early, reduce_lr],
    class_weight=class_weight_dict,
    verbose=1
)


# ------------------ Evaluate ------------------
val_probs = model.predict(X_val, verbose=0)
val_pred_int = np.argmax(val_probs, axis=1)

labels_all = list(range(len(label_enc.classes_)))
present = set(y_val_int) | set(val_pred_int)
missing = [label_enc.classes_[i] for i in labels_all if i not in present]
print("\nℹ️ Missing labels in val (or never predicted):", missing)

print("\n✅ Classification Report (Validation):")
print(classification_report(
    y_val_int,
    val_pred_int,
    labels=labels_all,
    target_names=label_enc.classes_,
    digits=3,
    zero_division=0
))

print("\n✅ Confusion Matrix (Validation):")
print(confusion_matrix(
    y_val_int,
    val_pred_int,
    labels=labels_all
))


# ------------------ Save model + meta ------------------
os.makedirs(OUT_DIR, exist_ok=True)

# ✅ recommended format
model.save(MODEL_PATH_KERAS)

# optional legacy export
try:
    model.save(MODEL_PATH_H5)
except Exception:
    pass

meta = {
    "vectorizer": vectorizer,
    "label_encoder": label_enc,
    "responses_map": dict(responses_map),

    "seed": SEED,
    "history_window": N_HISTORY,
    "history_k": HISTORY_K,
    "history_feature_names": HISTORY_FEATURE_NAMES,

    "intents_repeat": INTENTS_REPEAT,
    "db_repeat": DB_REPEAT,

    "use_core_intents": USE_CORE_INTENTS,
    "core_map": CORE_MAP if USE_CORE_INTENTS else {},

    "intents_cap_per_label": INTENTS_CAP_PER_LABEL,
    "intents_min_per_label": INTENTS_MIN_PER_LABEL,

    "tfidf_max_features": MAX_FEATURES,
    "tfidf_ngram_range": NGRAM_RANGE,
    "tfidf_min_df": MIN_DF,

    "labels": list(label_enc.classes_),
}

with open(META_PATH, "wb") as f:
    pickle.dump(meta, f)

print("\n✅ Training complete!")
print(f"Model saved to: {MODEL_PATH_KERAS}")
print(f"Meta saved to : {META_PATH}")
print("\nIMPORTANT (for Flask inference):")
print(" - use SAME clean_text()")
print(" - use SAME history_features() and HISTORY_FEATURE_NAMES order")
print(" - concatenate TFIDF + history in SAME order")
print(" - predicted tags are CORE labels (collapsed) because use_core_intents=True")